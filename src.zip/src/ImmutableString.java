
class Numbers implements Runnable{
	
	public void run() {
		for(int i =1;i<=26;i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
}
class Alphabates extends Thread{
	public void run() {
		for(char c = 'A'; c <= 'Z'; ++c) {
		      System.out.println(c + " ");
		      try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    }
	}
	
	
}



public class ImmutableString{

		public static void main(String[] args) throws InterruptedException {
//			String s1 =  new String("Pratiksha");
//			String s2 = "Pratiksha";
//			String s3=s1;
//			s1.concat("hi");
//			
//			System.out.println(s1);
//			System.out.println(s2);
//			System.out.println(s3);
			Alphabates a = new Alphabates();
			Numbers n1=new Numbers();
			Thread t1 = new Thread(n1);
			t1.start();
			Thread.sleep(10);
			Thread t2 = new Thread(a);
			t2.start();
			
		}
}
