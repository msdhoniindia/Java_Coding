
public class ManualTrim {
public static void main(String[] args) {
	
	String n = " Pratiksha Rao    ";
	System.out.println(n.length());
	char [] newchr = n.toCharArray();
	for(char c : newchr) {
		System.out.println(c);
	}
	int i = 0;
	int end = n.length();
	while(i< end && n.charAt(i)==' ') {
		i++;
	}
	while(end>i && n.charAt(end-1)==' ') {
		end--;
	}
System.out.println(n.substring(i, end));
	
}
	
	}
