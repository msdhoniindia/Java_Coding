
public class FiveLargest {

	public static void main(String[] args) {
		int arr[]= {4,7,3,1,6,9,8,10,13};
		int res[] = new int[5];
		int index=0;
		int max=Integer.MIN_VALUE;
		for(int j =0;j<5;j++) {
			max = 0;
			index=0;
			System.out.println(arr[j]);
				for(int i = 0;i<arr.length;i++) {
						if(arr[i]>max) {
							max=arr[i];
							index = i;
							
						}
						System.out.println(arr[i]);
				}
				res[j]=max;
				arr[index]=Integer.MIN_VALUE;
		}
		
		
//		for(int j =0;j<5;j++) {
//		System.out.println(arr[j]);
//		}
	}
}
