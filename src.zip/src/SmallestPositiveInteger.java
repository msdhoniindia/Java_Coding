
public class SmallestPositiveInteger {

	public static void main(String[] args) {
		int arr[]= {1,1,3,4};
		int a =smallestInteger(arr,arr.length);
		System.out.println(a);
	}

	private static int smallestInteger(int[] arr, int n) {
//		int sum = arr[0]+arr[1];
//		int j =1;
//		for(int i=0;i<sum-1;i++) {
//			if(arr[i]!=j) {
//				System.out.println(j);
//				break;
//			}
//			j++;
//		}
		
		
		int res=1;
		for(int i =0;i<n;i++) {
			System.err.print(i+" res="+res+" ");
			if(arr[i]>res) {
				return res;
			}else {res+=arr[i];}
				}
			return res;	
	}
}
