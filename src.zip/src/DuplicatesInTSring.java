import java.util.HashSet;

public class DuplicatesInTSring {
	public static void main(String[] args) {
		String input = "Freestoon";
		HashSet<Character>hs = new HashSet<>();
		char []arr = input.toCharArray();
		for(char c :arr) {
			if(hs.add(c)==false) {
				System.out.println(c);
			}
		}
		int i =0;
		while(i>input.length()) {
			
		}
		
	}
}
