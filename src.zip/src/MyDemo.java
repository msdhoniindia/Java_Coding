
class A{
			int a = 1;
			A(){
			System.out.println(a);
			a++;
			}
			}

			class B{
			static int b = 1;
			B(){
				System.out.println(b);
			b++;
			}
			}


			
public class MyDemo {

	public static void main(String[] args) {
		
			A a1 = new A();//1
			System.out.println();
			A a2 = new A();//2
			System.out.println();
			B b1 = new B();//1
			System.out.println();
			B b2 = new B();//2
			
}
}