package com.amdocs;

public class PermutionString {
	static char res;
	static void getsubSet(String in) {
		if (in==null) {
			System.out.println(in);
		}
		for(int i =0;i<in.length();i++) {
			res = in.charAt(i);
			getsubSet(res+in.substring(i));
		}
	}
	
	public static void main(String[] args) {
		String str=  "abc";
		getsubSet(str);
	}
}


//abc,acb,bac,bca,cab,cba