package com.amdocs;

public class SecondHighestInArray {
	public static void findSecondHighest() {
		int arr[] = {5,10,2,3,8,2,1};
		int max_element = Integer.MIN_VALUE;
		int sec_highest = 0;
		
		for(int i =0;i<arr.length;i++) {
			
			if(arr[i]>max_element) {
				sec_highest=max_element;
				max_element = arr[i];	
			}else {
				if(sec_highest<arr[i])
					sec_highest=arr[i];
			}
		}
		System.out.println(sec_highest);
	}
	
	public static void findPair(int total) {
		int arr[] = {5,10,2,3,8,2,1};
		for(int i=0;i<arr.length;i++) {
			
		}
		
	}
	public static void main(String[] args) {
		findSecondHighest();
		findPair(11);
	}
}
