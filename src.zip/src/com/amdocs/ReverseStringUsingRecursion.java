package com.amdocs;

public class ReverseStringUsingRecursion {
	static String reverseString = "";
	static int i = 0, j = 1;

	public static void main(String[] args) {

		String input = "India country";
		int n = input.length()-1;
		String res = reverseString(input, n);
		System.out.println(res);
		// System.err.println(input.substring(n-1,n));
	}

	private static String reverseString(String input, int length) {
		if(length<0) {
			return reverseString;
		}
		int len = input.length()-1;
		reverseString+=input.charAt(length);
		return reverseString(input.substring(0,len--),len--);

	}

}
