package com.amdocs;

import java.util.Scanner;

public class Fibnoacci {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		
		int a=fib(n);
		System.err.println(a);
		String s1="abc";
		s1="xyz";
		System.err.println(s1);
	}

	static int res=0;
	private static int fib(int n) {
	//System.out.println(p);
	if(n<=1) {
		return n;
	}
		return fib(n-1)+fib(n-2);
		
	}
		
		
		

}
