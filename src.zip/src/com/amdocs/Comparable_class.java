package com.amdocs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Student implements Comparator<Student>{
	int id;
	String name;
	Student(){}
	Student(String name,int id){
		this.name=name;
		this.id=id;
	}
	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		return o1.name.compareTo(o2.name);
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
}

public class Comparable_class{
	
	public static void main(String[] args) {
		Student s1 = new Student();
		List<Student> students = new ArrayList<>(Arrays.asList(
                new Student("John", 15),
                new Student("Sam", 25),
                new Student("Will", 20),
                new Student("Dan", 20),
                new Student("Joe", 10)
            ));
		
		 Collections.sort(students, new Student());

		 students.stream().forEach(x->System.out.println(x));
	}
	
	
}
