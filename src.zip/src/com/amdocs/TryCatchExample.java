package com.amdocs;

import java.util.ArrayList;

import javax.management.RuntimeErrorException;

class b{}
class h extends b{}
class i extends h{}
class travel{
	ArrayList<h>go(){
		return new ArrayList<>();
	}
}

public class TryCatchExample {
	static void m1() {
		System.out.println("m1");
		throw new NullPointerException();
	}
	static void m2() {
		System.out.println("m2");
	}
		static String s= "-";
		public static void main(String[] args) {
			try {
				throw new Exception();
			}catch(Exception e) {
				try {
					try {
						throw new Exception();
					}catch(Exception ex) {
						s+="ic ";
					}
					throw new Exception();
				}catch(Exception x) {
					s+="mc ";
				}finally{s+="mf ";}
			}finally{s+="of ";}
			
			try {
				m1();
				m2();
			}catch(Exception x) {
				System.out.println(x.getMessage());
			}
			System.out.println(s);
			
			
		}
}
