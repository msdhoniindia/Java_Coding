package com.amdocs;

class EvenThread extends Thread{
	
	public void run() {
		for(int i = 0 ;i<10;i++) {
			if((i&1)==0) {
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
}

class OddThread extends Thread{
	
	public void run() {
		for(int i = 0 ;i<10;i++) {
			if((i&1)==1) {
				System.out.println(i);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
}


public class ThreadExp {
public static void main(String[] args) throws InterruptedException {
	EvenThread e1= new EvenThread();
	OddThread o1 = new OddThread();
	Thread t1 = new Thread(o1);
	Thread t2 = new Thread(e1);
	t2.start();
	Thread.sleep(500);
	t1.start();
}
		
}
