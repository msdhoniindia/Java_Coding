package com.amdocs;

public class ImmutableClass {

	private  final int id ;
	private final String name;
	
	ImmutableClass(int id , String name){
	
		this.id=id;
		this.name=name;
	
	}
	
	int getId(){
	
		return id;
	}
	
	String getString(){
		return name;
	}
	
	public static void main(String[] args) {
		
		ImmutableClass d =new ImmutableClass(1,"India");
		int user_id=d.getId();
		System.out.println(user_id);
	
	}

		
	}
	
	

