package com.amdocs;

class A {
static int i = 10;
int j = 20;
}


public class Demo {

	public static void main(String[] args) {
		int n =5;
		for(int i =0;i<5;i++){
			if(i>0){
			for(int k =0;k<i;k++)
				System.out.print(" ");
			}
			for(int j=n-i;j>=1;j--){
				System.out.print(j);
			 }
			System.out.println();

			}
			A a1 = new A();
			a1.i = 30;
			A.i = 40;
			a1.j = 50;
		//	A.j = 60;
			A a2 = new A();
			a2.i = 70;
			A.i = 80;
			a2.j = 90;
		//	A.j = 100;

			
			System.out.println(a1.i);
			System.out.println(A.i); //80
			System.out.println(a1.j);//50
		//	System.out.println(A.j);//100
			System.out.println(a2.i);
			System.out.println(A.i);//80
			System.out.println(a2.j);//90
		//	System.out.println(A.j);//100
		
	}
}
