
public class Thread3 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
