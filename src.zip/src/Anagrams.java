import java.util.ArrayList;

public class Anagrams {

	public static void main(String[] args) {
		String one = "army";
		String two = "majy";
		int f=0;

		ArrayList<Character> c = new ArrayList<>();
		for (int i = 0; i < one.length(); i++) {
			c.add(one.charAt(i));
		}
		for (int j = 0; j < two.length(); j++) {
			if (!c.contains(two.charAt(j))) {
				System.out.println("Not Anargrams");
				f=1;
				break;
			}
		}
		
		if(f==0) {System.err.println("Anagrams");}
		
	}
}
