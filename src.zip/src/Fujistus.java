class one
{
public void Display() {
	System.out.println("in A");
}
}

class two extends one

{
public void Display() {
	System.out.println("in B");
}
}

class three extends two
{
public void Display() {
	System.out.println("in c");
}
}


public class Fujistus {
	public static void main(String[] args) {
		one objA= new one();
		two objB = new two();
		three objC = new three();
		objA = objB;
		objA.Display(); // which method gets Called?A or B? --> B
		objC.Display();// which method gets Called?C or B? --->C
		objA = objC;// which method gets Called?C or B?
		objA.Display(); // which method gets Called?A or C?--> C
	}
	
}
