interface Myinterface{
	
	void print();
	
}

interface youInterface{
	
	 void print();
}

public class TwoInterfacses  implements Myinterface  {

	
	public static void main(String[] args) {
		new TwoInterfacses().print();
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		
	}




}
