
public class LargestCommonPrefix {

	public static void main(String[] args) {
		int N = 4;
		String	arr[] = {"geeksforgeeks", "geeks", "geek",
				         "geezer"};
		
		String prefix =arr[0];
		String abc = "";
;		for(int i =1;i<arr.length;i++) {
			abc = getLongestPrefix(prefix,arr[i]);
		}
		System.out.println(abc);
	}

	private static String getLongestPrefix(String prefix, String str) {
		String res="";
		for(int i=0,j=0;i<prefix.length()&&j<str.length();i++,j++) {
			if(prefix.charAt(i)!=str.charAt(j)) break;
			res+=prefix.charAt(i);
		}
		
		return res;
	}
}
