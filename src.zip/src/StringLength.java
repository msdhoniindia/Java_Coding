
public class StringLength {
	static int n=-1;
		public static void main(String[] args) {
			String str = "Pratiksha";
			int i = 0;
			char c[] = str.toCharArray();
			for(char p:c) {
				i++;
			}
			System.out.println(i);
		
		
		//Using recursion
			
			int j = getLength(str);
			System.out.println(j);
			
		//using while
			int n =c.length;
			while(n<0){
				i++;
				n--;
			}
			System.out.println(i);
		}
		
		private static int getLength(String str) {
			if(str.equals("")) {
				return 0;
			}
			return getLength(str.substring(1))+1;
			
		}
}
