
public class ClosetString {

	public static void main(String[] args) {
		String S[] = { "the", "quick", "brown", "fox", 
	     "quick"};
	String word1 = "quick";
	String word2 = "fox";
	int j=0;int k =0;
	
		for(int i=0;i<S.length;i++) {
			if(S[i]==word1) {
				 j=i;
			}
			if(S[i]==word2) {
				 k =i;
			}
		}
		
		System.out.println(j-k);
	}
}
