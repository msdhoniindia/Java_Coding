import java.util.*;
public class FinFirstRepeating {

		public static void main(String[] args) {
			
			int arr[]= {10,5,3,4,3,5,6};
			findFirstElement(arr);
		}

		private static void findFirstElement(int[] arr) {
//			outerLoop:
//			for(int i = 0;i<arr.length;i++) {
//				for(int j =i+1;j<arr.length;j++) {
//					if(arr[i]==arr[j]) {
//						System.out.println(arr[i]);
//						break outerLoop;
//					}
//				}
//			}
			
			int min=-1;
			Set<Integer> hs = new HashSet<>();
			for(int i =arr.length-1;i>=0;i--) {
				//System.out.print(arr[i]+",");
				//System.out.println();
				if(!hs.contains(arr[i])) {
					min=i;
					
				}
				hs.add(arr[i]);
			}
			
			if(min!=-1) {
				System.err.println(arr[min]);
			}
			
		}
}
