
public class WordsReversed {

		public static void main(String[] args) {
			 String arr[] = "i#like#this#program#very#much".split("#");
			 String op = "";
			 int n =arr.length;
			System.out.println(arr.length);
			for(int i = arr.length-1;i>=0;i--) {
				op+=arr[i]+".";
			}
			
			System.out.println(op.substring(0,op.length()-1));
		}
}
