import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Occur {

	public static void main(String[] args) {
		String s = "aabbbcccccdddddd";
		String s1="abc";
		s1="xyz";
		System.err.println(s1);

		HashMap<Character,Integer> hm = new HashMap<>();
		
		for(int i =0 ;i<s.length();i++){
			
			if(hm.containsKey(s.charAt(i))){
			hm.put(s.charAt(i),hm.get(s.charAt(i))+1);
			}
			else{
			hm.put(s.charAt(i),1);
			}
			
		}

List<String> emp = new ArrayList<String>();

emp.stream().filter(x->x=="IT").forEach(i->System.err.println(i));
		
		System.out.println(hm);
	}
}
