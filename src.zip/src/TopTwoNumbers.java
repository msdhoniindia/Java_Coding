
public class TopTwoNumbers {

	public static void main(String[] args) {
		int arr[]= {10,5,3,4,3,5,6};
		TopTwonumbers(arr);
	}

	private static void TopTwonumbers(int[] arr) {
		int max=Integer.MIN_VALUE;
		int second_max = 0;
		
		for(int i = 0;i<arr.length-1;i++) {
			if(arr[i]>max) {
				second_max=max;
				max=arr[i];
			}else {
				if(arr[i]>second_max) {
					second_max=arr[i];
				}
			}
		}
		
		System.out.println("Max::"+max+" Second_Max::"+second_max);
	}
}
